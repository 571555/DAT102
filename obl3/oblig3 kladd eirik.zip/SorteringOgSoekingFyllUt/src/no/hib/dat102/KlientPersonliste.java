package no.hib.dat102;

public class KlientPersonliste {

	public static void main(String[] args) {

		Person[] personer = new Person[7];
		personer[0] = new Person("Ole", "Sandvik");
		personer[1] = new Person("Lise", "Barvik");
		personer[2] = new Person("Marius", "Rein");
		personer[3] = new Person("Laura", "Gjertsen");
		personer[4] = new Person("Frank", "Alstad");
		personer[5] = new Person("Lars", "Selvik");
		personer[6] = new Person("Elise", "Alstad");
		/**************************************************/
		Person[] personerS = new Person[7];
		for (int i = 0; i <= personerS.length - 1; i++) {
			personerS[i] = personer[i];
		}

		// Utskrift av data
		System.out.println("\n Originale data ");
		for (int i = 0; i < personer.length; i++) {
			System.out.println(personer[i]);
		}
		/* Line�r s�king i usortert tabell , venner */
		/* Line�rs�king som returnerer sann eller usann */
		Person person1 = personer[2];
		Person person2 = new Person("Ole", "Olsen");
		boolean funnet = false;

		System.out.println("\nUtskrift fra  linearSok som returnerer sann eller usann ");

		funnet = SoekingOgSortering.linearSoekU(personer, 0, personer.length - 1, person1);

		if (funnet) {
			System.out.println(person1 + " er med");
		} else {
			System.out.println(person1 + " er ikke med");
		}

		funnet = SoekingOgSortering.linearSoekU(personer, 0, personer.length - 1, person2);

		if (funnet) {
			System.out.println(person2 + " er med");
		} else {
			System.out.println(person2 + " er ikke med");
		}

		/* S�king i sortert tabell */

		person1 = personerS[3];
		// OBS! Lager f�rst en tabell av sorterte data f�r vi bruker
		// linears�king i sortert tabell og bin�rs�king.
		/* Sorterer tabellen */
		SoekingOgSortering.utvalgSortering(personerS);

		// Utskrift av data
		System.out.println("\n Sorterte  data ");
		for (int i = 0; i < personerS.length; i++) {
			System.out.println(personerS[i]);
		}

		/*
		 * Line�r s�king i en sortert tabell * / Line�rs�king som returnerer
		 * sann eller usann
		 */
		System.out.println("\nUtskrift fra linearSokSortert som returnerer sann eller usann ");

		funnet = SoekingOgSortering.linearSoekS(personerS, 0, personerS.length - 1, person1);

		if (funnet) {
			System.out.println(person1 + " er med");
		} else {
			System.out.println(person1 + " er ikke med");
		}

		funnet = SoekingOgSortering.linearSoekS(personerS, 0, personerS.length - 1, person2);

		if (funnet) {
			System.out.println(person2 + " er med");
		} else {
			System.out.println(person2 + " er ikke med");
		}

		/* Bin�rs�king - tabellen er sortert */

		/* Alt 1 Bin�rs�king som returnerer sann eller usann */
		System.out.println("\n Alt 1 Utskrift fra rekursiv binaersoking som returnerer sann eller usann ");

		funnet = SoekingOgSortering.binaerSoek(personerS, 0, personerS.length - 1, person1);

		if (funnet) {
			System.out.println(person1 + " er med");
		} else {
			System.out.println(person1 + " er ikke med");
		}

		funnet = SoekingOgSortering.binaerSoek(personerS, 0, personerS.length - 1, person2);
		if (funnet) {
			System.out.println(person2 + " er med");
		} else {
			System.out.println(person2 + " er ikke med");
		}

		//
		/* Alt 2 Bin�rs�king som returnerer sann eller usann */
		System.out.println("\n Alt 2 :Utskrift fra rekursiv binaersoking som returnerer sann eller usann ");

		funnet = SoekingOgSortering.binaerSoek2(personerS, 0, personerS.length - 1, person1);

		if (funnet) {
			System.out.println(person1 + " er med");
		} else {
			System.out.println(person1 + " er ikke med");
		}
		
		funnet = SoekingOgSortering.binaerSoek2(personerS, 0, personerS.length - 1, person2);
		
		if (funnet) {
			System.out.println(person2 + " er med");
		} else {
			System.out.println(person2 + " er ikke med");
		}

		// Alt 3
		/* Rekursiv bin�rs�king som returnerer indeksen, -1 ved ikke-funn */
		System.out.println("\n Alt 3 Utskrift fra  rekursiv binaersoking som returnerer indeksen, -1 ved ikke-funn.");

		int ind = SoekingOgSortering.binaerSoek3(personerS, 0, personerS.length - 1, person1);

		if (ind > 1) {
			System.out.println(personerS[ind] + " er med");
		} else {
			System.out.println(person2 + " er ikke med");
		}

		ind = SoekingOgSortering.binaerSoek3(personerS, 0, personerS.length - 1, person2);

		if (ind > 1) {
			System.out.println(personerS[ind] + " er med");
		} else {
			System.out.println(person2 + " er ikke med");
		}

		/*
		 * Ikke-rekursiv bin�rs�king som returnerer indeksen, -1 ved ikke-funn
		 */

		/*
		 * System.out.
		 * println("\nUtskrift fra rekursiv binaersoking som returnerer indeksen, -1 ved ikke-funn."
		 * );
		 * 
		 * ind = SoekingOgSortering.binaerSoek4(personerS, 0, personerS.length -
		 * 1, person1);
		 * 
		 * if (ind > 1) { System.out.println(personerS[ind] + " er med"); } else
		 * { System.out.print(person1 + " er ikke med"); }
		 * 
		 */

	}// main
}// class
